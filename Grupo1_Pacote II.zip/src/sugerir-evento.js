function enviarSugestao() {
    alert("Obrigado! Sua sugestão foi registrada com sucesso");
}