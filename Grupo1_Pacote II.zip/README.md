**Getting started** 

*Git Flow Tools*

1. Download Git <https://git-scm.com/>
2. Open Git Bash
3. Clone the repository with the command *git clone https://github.com/anahelenasilva/disciplina-ux.git*

*Dependencies*

You don't have to download it.

1. Bootstrap 4 <https://getbootstrap.com/>
2. Font Awesome <https://fontawesome.com/v4.7.0/>

*First Look*

1. Open the file */src/index.html* on your browser
2. That's all.

